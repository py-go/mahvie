import { Environment } from '@models/core.model';

export const environment: Environment = {
  production: false,
  baseUrl: 'http://mahvie.com:8000/api/',
};

